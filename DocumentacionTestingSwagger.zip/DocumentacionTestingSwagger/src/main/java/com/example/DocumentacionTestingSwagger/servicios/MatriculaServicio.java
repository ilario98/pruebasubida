/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.DocumentacionTestingSwagger.servicios;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.DocumentacionTestingSwagger.modelos.Auto;
import java.util.Optional;
import com.example.DocumentacionTestingSwagger.modelos.Matricula;
import com.example.DocumentacionTestingSwagger.modelos.MatriculaMapper;
import com.example.DocumentacionTestingSwagger.repositorios.AutoRepositorio;

@Service
public class MatriculaServicio {

    @Autowired
    private MatriculaMapper mapper;

    @Autowired
    private AutoServicio autoServicio;
    
    @Autowired
    private PersonaServicio personaServicio;
    
    public int guardar(Matricula in) {
        autoServicio.guardar(mapper.toAuto(in));
        personaServicio.guardar(mapper.toPersona(in));
        return 1;
    }

}
