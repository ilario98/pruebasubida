package com.example.pruebaderrores1;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pruebaderrores1ApplicationTests {


}
