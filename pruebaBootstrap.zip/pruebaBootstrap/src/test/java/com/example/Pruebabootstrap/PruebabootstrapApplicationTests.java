package com.example.Pruebabootstrap;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebabootstrapApplicationTests {


}
