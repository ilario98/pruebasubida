package com.example.problema2webinar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Problema2webinarApplication {

	public static void main(String[] args) {
		SpringApplication.run(Problema2webinarApplication.class, args);
	}

}
