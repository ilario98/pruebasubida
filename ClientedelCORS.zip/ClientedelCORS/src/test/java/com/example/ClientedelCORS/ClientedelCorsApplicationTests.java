package com.example.ClientedelCORS;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientedelCorsApplicationTests {



}
