/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.pruebaderrores1.error;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
/**
 *
 * @author david.ilario
 */
public class ProductoNotFoundException extends RuntimeException {
       
    private static final long serialVersionUID=1L;
    
    public ProductoNotFoundException(long id){
        super("no se puede encontrar el producto con la ID: "+ id);
    }
}
