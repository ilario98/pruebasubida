/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.pruebaderrores1.error;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

import org.springframework.http.HttpStatus;

@Getter @Setter
/**
 *
 * @author david.ilario
 */
public class ApiError {
    private HttpStatus estado;
    
    @JsonFormat(shape = Shape.STRING, pattern="dd/MM/yyyy h:mm:ss")
    private LocalDateTime fecha;
    private String mensaje;
    
}
