package com.example.DocumentacionTestingSwagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentacionTestingSwaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentacionTestingSwaggerApplication.class, args);
	}

}
