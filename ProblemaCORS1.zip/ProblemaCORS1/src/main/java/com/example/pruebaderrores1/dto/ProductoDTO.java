package com.example.pruebaderrores1.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductoDTO {
	
	private long id;
	private String nombre;
	private String categoria;

}
