package com.example.ClientedelCORS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientedelCorsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientedelCorsApplication.class, args);
	}

}
