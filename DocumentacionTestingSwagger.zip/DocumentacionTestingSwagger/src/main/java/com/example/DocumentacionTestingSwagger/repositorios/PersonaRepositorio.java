package com.example.DocumentacionTestingSwagger.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.example.DocumentacionTestingSwagger.modelos.Persona;

public interface PersonaRepositorio extends CrudRepository<Persona, String> {

}
