package com.example.problema2webinar;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Problema2webinarApplicationTests {



}
