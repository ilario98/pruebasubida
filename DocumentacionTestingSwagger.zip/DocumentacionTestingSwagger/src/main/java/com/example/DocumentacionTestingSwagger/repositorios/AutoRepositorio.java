package com.example.DocumentacionTestingSwagger.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.example.DocumentacionTestingSwagger.modelos.Auto;

public interface AutoRepositorio extends CrudRepository<Auto, String> {

}
