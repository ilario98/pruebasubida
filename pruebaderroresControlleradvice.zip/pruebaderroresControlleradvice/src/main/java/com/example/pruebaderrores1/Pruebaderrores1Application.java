package com.example.pruebaderrores1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pruebaderrores1Application {

	public static void main(String[] args) {
		SpringApplication.run(Pruebaderrores1Application.class, args);
	}

}
